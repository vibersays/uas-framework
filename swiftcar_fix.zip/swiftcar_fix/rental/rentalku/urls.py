from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('service/', views.service, name='service'),
    path('blog/', views.blog, name='blog'),
    path('blog/<slug:slug>/', views.blog_detail, name='blog_detail'),
    path('contact/', views.contact, name='contact'),
    path('feature/', views.feature, name='feature'),
    path('cars/', views.cars, name='cars'),
    path('team/', views.team, name='team'),
    path('testimoni/', views.testimoni, name='testimoni'),
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)