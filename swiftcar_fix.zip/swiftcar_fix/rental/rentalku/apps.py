from django.apps import AppConfig


class RentalkuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rentalku'
