from django.db import models
from django.urls import reverse
from django.utils.text import slugify


class Author(models.Model):
    name = models.CharField(max_length=100, verbose_name = 'Nama Penulis')
    bio = models.TextField(verbose_name = 'Biodata Penulis')

    def __str__(self):
        return self.name


class Promo(models.Model):
    title = models.CharField(max_length=200, verbose_name = 'Nama Promo')
    subtitle = models.CharField(max_length=200, verbose_name = 'Isi Promo')
    created_at = models.DateTimeField(auto_now_add=True)
    image = models.ImageField(upload_to='assets/img/')

    def __str__(self):
        return self.title


class Post(models.Model):
    judul = models.CharField(max_length=200, verbose_name='Judul Berita')
    content = models.TextField(verbose_name='Isi Berita')
    author = models.ForeignKey('Author', on_delete=models.CASCADE, verbose_name='Nama Penulis')
    image = models.ImageField(upload_to='assets/img/post')
    created_at = models.DateField(auto_now_add=True)

    @property
    def slug(self):
        return slugify(self.judul)

    def get_absolute_url(self):
        return reverse('blog_detail', kwargs={'slug': self.slug})

    def __str__(self):
        return self.judul


class Car(models.Model):
    title = models.CharField(max_length=200, verbose_name='Nama Mobil')
    description = models.CharField(max_length=200, verbose_name='Rincian Singkat Mobil')
    price = models.IntegerField(verbose_name='Biaya Sewa')
    image = models.ImageField(upload_to='assets/img/carsrent')

    def __str__(self):
        return self.title


class Tim(models.Model):
    namaorang = models.CharField(max_length=200, verbose_name='Nama Orang')
    jabatan = models.CharField(max_length=200, verbose_name='Jabatan')
    image = models.ImageField(upload_to='assets/img/persontim')

    def __str__(self):
        return self.namaorang


class Testimoni(models.Model):
    namaorang = models.CharField(max_length=200, verbose_name='Nama Orang')
    jabatan = models.CharField(max_length=200, verbose_name='Jabatan')
    testimoni = models.CharField(max_length=200, verbose_name='Testimoni')
    image = models.ImageField(upload_to='assets/img/persontim')

    def __str__(self):
        return self.namaorang
