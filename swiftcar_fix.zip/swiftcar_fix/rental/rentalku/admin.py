from django.contrib import admin
from .models import Author, Promo, Post, Car, Tim, Testimoni


class AuthorAdmin(admin.ModelAdmin):
    list_display = ('name', 'bio')
    list_filter = ('name',)
    search_fields = ('name', 'bio')
    list_per_page = 2


class PromoAdmin(admin.ModelAdmin):
    list_display = ('title', 'subtitle', 'created_at','image')
    list_filter = ('title',)


class PostAdmin(admin.ModelAdmin):
    list_display = ('judul', 'author', 'created_at', 'image')
    list_filter = ('judul',)
    search_fields = ('judul', 'slug')
    list_per_page = 3


class CarAdmin(admin.ModelAdmin):
    list_display = ('title', 'price', 'image')


class TimAdmin(admin.ModelAdmin):
    list_display = ('namaorang', 'jabatan', 'image')


class TestimoniAdmin(admin.ModelAdmin):
    list_display = ('namaorang', 'testimoni')


admin.site.register(Author, AuthorAdmin)
admin.site.register(Promo, PromoAdmin)
admin.site.register(Post, PostAdmin)
admin.site.register(Car, CarAdmin)
admin.site.register(Tim, TimAdmin)
admin.site.register(Testimoni, TestimoniAdmin)
