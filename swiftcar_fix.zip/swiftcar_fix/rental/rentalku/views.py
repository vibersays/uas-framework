from django.shortcuts import get_object_or_404, render
from .models import Promo, Post, Car, Tim, Testimoni


def index(request):
    promos = Promo.objects.last()
    return render(request, 'index.html', {'promos': promos})


def about(request):
    return render(request, 'about.html')


def service(request):
    return render(request, 'service.html')


def blog(request):
    posts = Post.objects.all().order_by('-created_at')[:3]
    return render(request, 'blog.html', {'posts': posts})


def blog_detail(request, slug):
    post = get_object_or_404(Post, judul__iexact=slug.replace('-', ' '))
    return render(request, 'blog_detail.html', {'post': post})


def contact(request):
    return render(request, 'contact.html')


def feature(request):
    return render(request, 'feature.html')


def cars(request):
    posts = Car.objects.all()
    return render(request, 'cars.html', {'posts': posts})


def team(request):
    tims = Tim.objects.all()
    return render(request, 'team.html', {'tims': tims})


def testimoni(request):
    testims = Testimoni.objects.all()
    return render(request, 'testimoni.html', {'testims': testims})
